LOAN_PRINCIPAL = 'Loan principal: 1000'
FINAL_OUTPUT = 'The loan has been repaid!'
FIRST_MONTH = 'Month 1: repaid 250'
SECOND_MONTH = 'Month 2: repaid 250'
THIRD_MONTH = 'Month 3: repaid 500'


def main():
    print(LOAN_PRINCIPAL, FIRST_MONTH, SECOND_MONTH, THIRD_MONTH, FINAL_OUTPUT, sep='\n')


if __name__ == '__main__':
    main()
